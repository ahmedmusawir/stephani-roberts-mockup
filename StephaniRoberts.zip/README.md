# bootsass-workflow
This is the workflow for Bootstrap 3.1 and SCSS with Compass. Just clone it and Go !!


Compass
If you are using Compass then you’ll have Ruby installed. With Ruby installed we can use gems, in this case the bootstrap-sass gem. To install:
###gem install bootstrap-sass

If you have an existing Compass project and want to add bootstrap-sass, run this command:
###compass install bootstrap -r bootstrap-sass

If you want to start a new Compass project with bootstrap-sass use:
###compass create my-new-project -r bootstrap-sass --using bootstrap

Bower
We can also install it with the package manager Bower. To me this option is the best as the other options install a lot of ‘fluff’ that will confuse someone not familiar with Bootstrap. To install with Bower make sure you are in the folder where you want to create your project and run:
###bower install bootstrap-sass
